#!/usr/bin/env python

import rospy
from std_msgs.msg import String

def talker():
    pub = rospy.Publisher('lee', String, queue_size=10)
    rospy.init_node('talker', anonymous=True)
    rate = rospy.Rate(20) 
    k = input("k=")
    n = 4
    while not rospy.is_shutdown():
        rospy.loginfo(k)
        pub.publish(k)
        k = k + n
        rate.sleep()

if __name__ == '__main__':
    try:
        talker()
    except rospy.ROSInterruptException:
        pass
        

