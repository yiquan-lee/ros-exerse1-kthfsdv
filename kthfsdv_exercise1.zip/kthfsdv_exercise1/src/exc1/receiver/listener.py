#!/usr/bin/env python

import rospy
from std_msgs.msg import String

def callback(data):
    rospy.loginfo(rospy.get_caller_id() + 'I heard %s', data.data)

def listener():
    rospy.init_node('listener', anonymous=True)
    k = rospy.Subscriber('lee', String, callback)
    pub = rospy.Publisher('/kthfs/result', String, queue_size=10)
    rate = rospy.Rate(20)
    while not rospy.is_shutdown():
        a = k / 0.15
        rospy.loginfo(a)
        pub.publish(a)
    rospy.spin()

if __name__ == '__main__':
    listener()
